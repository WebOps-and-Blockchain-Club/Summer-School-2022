document.getElementById("myButton").onclick = function(){
    var Input1 = document.getElementById("input1").value;
    var Input2 = document.getElementById("input2").value;
    var Input3 = document.getElementById("input3").value;
    var Input4 = document.getElementById("input4").value;
    console.log(Input1,"\n",Input2,"\n",Input3,"\n",Input4);
}